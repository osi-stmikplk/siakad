<?php /*
Layout ini digunakan untuk request terhadap page berbasiskan ajax, jadi tidak lagi diikutsertakan untuk mengambil
header dari halaman seperti halnya layout.main. Apabila ada dependency maka harap di deklarasikan sendiri.
@Feb  2016 Yan F
*/ ?>
<?php /* Content Header (Page header) */ ?>
<section class="content-header">
    <?php echo $__env->yieldContent('content-header'); ?>
</section>
<?php /* Main content */ ?>
<section class="content">
    <?php echo $__env->yieldContent('content'); ?>
</section>
<?php /* /.content */ ?>
<?php echo $__env->yieldPushContent('late-script'); ?>