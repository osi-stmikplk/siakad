<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b><?php echo e(config('siakad.nama')); ?></b>
        <b style="display: none;">Version <?php echo e(config('siakad.versi')); ?></b>
    </div>
    <strong>IT STMIK Palangkaraya</strong>
    <strong style="display: none;">Copyright &copy; 2016-<?php echo e(date('Y')); ?> <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights
    reserved.
</footer>