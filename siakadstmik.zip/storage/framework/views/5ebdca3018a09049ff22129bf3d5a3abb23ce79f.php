<?php /*
Load tampilan pertama kali / Dashboard
*/ ?>


<?php $__env->startSection('content-header'); ?>
    <h1>STMIK Siakad<small>kepingin online</small></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="dashboard">
    <div class="box box-default">
        <div class="box-header with-border">
            <i class="fa fa-bullhorn"></i>
            <h3 class="box-title">Perhatian</h3>
        </div><!-- /.box-header -->
        <div class="box-body">
            <div class="callout callout-danger">
                <p>Masih Prototype Coy!</p>
            </div>
        </div><!-- /.box-body -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>