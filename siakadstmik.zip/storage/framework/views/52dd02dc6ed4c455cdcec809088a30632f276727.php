<?php $__env->startSection('content-header'); ?>
    <h1>Data Diri Mahasiswa<small>udpate data yang kekinian</small></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="data-diri">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-default">
                <div class="box-body">
                    <p class="alert alert-info">
                        <i class="fa fa-info-circle"></i> Segera hubungi AKMA untuk data yang tidak bisa Anda edit namun keliru dimasukkan.</p>
                    <?php echo $__env->make('mahasiswa.data-diri.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>