<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('kejar.title')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- intercooler data previx is a must -->
    <meta name="intercoolerjs:use-data-prefix" content="true"/>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/btable/bootstrap-table.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <?php /*<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">*/ ?>
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('lte/css/AdminLTE.min.css')); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(asset('lte/css/skins/_all-skins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('TSSTMIK.css')); ?>">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <?php echo $__env->make("layout.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- =============================================== -->
    <?php echo $__env->make('layout.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- =============================================== -->
    <!-- Content Wrapper. Contains page content -->
    <div id="the-content" class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <?php echo $__env->yieldContent('content-header'); ?>
        </section>

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make("layout.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- ./wrapper -->
<?php /* Digunakan untuk yang ingin menggunakan modal */ ?>
<div class="modal fade"
     id="modal-util"
     <?php /*Bug karena field tidak dapat autofocus di dialog window bootstrap adalah tabindex="-1" di remove*/ ?>
     <?php /*tabindex="-1" */ ?>
     role="dialog" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 id="modal-util-title" class="modal-title"><?php echo e(config('siakad.nama')); ?></h4>
            </div>
            <div id="modal-util-body" class="modal-body">Tunggu Sedang loading ...</div>
        </div>
    </div>
</div>
<!-- jQuery 2.2.0 -->
<script src="<?php echo e(asset('plugins/jQuery/jQuery-2.2.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/intercooler/intercooler-0.9.4.min.js')); ?>"></script>
<!-- Bootstrap 3.3.5 -->
<script src="<?php echo e(asset('plugins/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/btable/bootstrap-table.min.js')); ?>"></script>
<!-- SlimScroll -->
<?php /*<script src="<?php echo e(asset('plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>*/ ?>
<!-- FastClick -->
<?php /*<script src="<?php echo e(asset('plugins/fastclick/fastclick.min.js')); ?>"></script>*/ ?>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('lte/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('TSSTMIK.js')); ?>"></script>
<?php echo $__env->yieldPushContent('late-script'); ?>
</body>
</html>
