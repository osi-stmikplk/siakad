<div id="alerter-success" class="form-group" style="display: none;">
    <div class="col-md-12">
        <div class="alert alert-success">
            <span id="message-success"></span>
        </div>
    </div>
</div>
<div id="alerter-error" class="form-group" style="display: none;">
    <div class="col-md-12">
        <div class="alert alert-danger">
            <span id="message-error"></span>
        </div>
    </div>
</div>