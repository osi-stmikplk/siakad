<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>{{ config('siakad.nama') }}</b>
        <b style="display: none;">Version {{ config('siakad.versi') }}</b>
    </div>
    <strong>IT STMIK Palangkaraya</strong>
    <strong style="display: none;">Copyright &copy; 2016-{{ date('Y') }} <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights
    reserved.
</footer>