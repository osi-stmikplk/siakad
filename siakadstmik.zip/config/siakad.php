<?php
/**
 * Masukkan disini adalah setting global untuk siakad kita tercinta :D
 * User: toni
 * Date: 09/04/16
 * Time: 10:01
 */
return [
    'nama' => 'SIAKADpinginOl',
    'versi' => '0.1',
];