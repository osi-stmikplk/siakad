<?php

namespace Stmik;

use Illuminate\Database\Eloquent\Model;

class OrangTua extends Model
{
    //
}
