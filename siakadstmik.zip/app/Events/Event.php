<?php

namespace Stmik\Events;

abstract class Event
{
    //
}
