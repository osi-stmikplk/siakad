<?php

namespace Stmik;

use Illuminate\Database\Eloquent\Model;

class Nilai extends Model
{
    //
}
